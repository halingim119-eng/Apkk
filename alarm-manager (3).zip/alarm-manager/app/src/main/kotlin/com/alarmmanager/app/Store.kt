package com.alarmmanager.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Entry(
    val time: Long,
    val app: String,
    val room: String,
    val text: String,
    val deleted: Boolean
)

data class Recv(
    val time: Long,
    val app: String,
    val room: String,
    val state: String,
    val detail: String = ""
)

object Store {
    const val KAKAO = "kakao"
    const val DISCORD = "discord"

    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("am", Context.MODE_PRIVATE)

    fun label(app: String) = if (app == KAKAO) "카카오톡" else "디스코드"

    // 대상 앱
    fun mode(c: Context): String = prefs(c).getString("mode", "") ?: ""
    fun setMode(c: Context, m: String) = prefs(c).edit().putString("mode", m).apply()
    fun apps(c: Context): List<String> = when (mode(c)) {
        "kakao" -> listOf(KAKAO)
        "discord" -> listOf(DISCORD)
        "both" -> listOf(KAKAO, DISCORD)
        else -> emptyList()
    }

    // 방 / 서버 목록
    private fun set(c: Context, key: String): MutableSet<String> =
        HashSet(prefs(c).getStringSet(key, emptySet()) ?: emptySet())

    fun muted(c: Context, app: String): Set<String> = set(c, "muted_$app")

    fun rooms(c: Context, app: String): List<String> =
        (set(c, "known_$app") + set(c, "muted_$app")).sortedBy { it.lowercase() }

    fun addKnown(c: Context, app: String, name: String) {
        val s = set(c, "known_$app")
        if (s.add(name)) prefs(c).edit().putStringSet("known_$app", s).apply()
    }

    fun addMuted(c: Context, app: String, name: String) {
        addKnown(c, app, name)
        setMuted(c, app, name, true)
    }

    fun setMuted(c: Context, app: String, name: String, on: Boolean) {
        val s = set(c, "muted_$app")
        if (on) s.add(name) else s.remove(name)
        prefs(c).edit().putStringSet("muted_$app", s).apply()
    }

    fun removeRoom(c: Context, app: String, name: String) {
        val k = set(c, "known_$app").apply { remove(name) }
        val m = set(c, "muted_$app").apply { remove(name) }
        prefs(c).edit().putStringSet("known_$app", k).putStringSet("muted_$app", m).apply()
    }

    // 멘션
    fun deleteMention(c: Context) = prefs(c).getBoolean("del_mention", true)
    fun setDeleteMention(c: Context, v: Boolean) = prefs(c).edit().putBoolean("del_mention", v).apply()

    fun keywords(c: Context): String = prefs(c).getString("keywords", "") ?: ""
    fun setKeywords(c: Context, v: String) = prefs(c).edit().putString("keywords", v).apply()

    fun isMention(c: Context, text: String): Boolean {
        val t = text.lowercase()
        return keywords(c).split(",")
            .map { it.trim().removePrefix("@").lowercase() }
            .filter { it.isNotEmpty() }
            .any { t.contains("@$it") }
    }

    // 통계
    fun blocked(c: Context) = prefs(c).getInt("blocked", 0)
    fun bumpBlocked(c: Context) = prefs(c).edit().putInt("blocked", blocked(c) + 1).apply()

    // 로그
    @Synchronized
    fun addLog(c: Context, e: Entry) {
        val arr = JSONArray(prefs(c).getString("log", "[]"))
        arr.put(
            JSONObject()
                .put("t", e.time).put("a", e.app).put("r", e.room)
                .put("x", e.text).put("d", e.deleted)
        )
        while (arr.length() > 200) arr.remove(0)
        prefs(c).edit().putString("log", arr.toString()).apply()
    }

    fun log(c: Context): List<Entry> {
        val arr = JSONArray(prefs(c).getString("log", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getLong("t"), o.getString("a"), o.getString("r"), o.getString("x"), o.getBoolean("d"))
        }.reversed()
    }

    fun clearLog(c: Context) = prefs(c).edit().putString("log", "[]").apply()

    fun norm(s: String): String = s.lowercase().filter { !it.isWhitespace() }

    // 최근 받은 알림
    @Synchronized
    fun addRecv(c: Context, r: Recv) {
        val arr = JSONArray(prefs(c).getString("recv", "[]"))
        arr.put(
            JSONObject().put("t", r.time).put("a", r.app).put("r", r.room).put("s", r.state).put("d", r.detail)
        )
        while (arr.length() > 30) arr.remove(0)
        prefs(c).edit().putString("recv", arr.toString()).apply()
    }

    fun recv(c: Context): List<Recv> {
        val arr = JSONArray(prefs(c).getString("recv", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Recv(o.getLong("t"), o.getString("a"), o.getString("r"), o.getString("s"), o.optString("d", ""))
        }.reversed()
    }
}
