package com.alarmmanager.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Exception) {
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val app = when (sbn.packageName) {
            "com.kakao.talk" -> Store.KAKAO
            "com.discord" -> Store.DISCORD
            else -> return
        }
        if (app !in Store.apps(this)) return

        val n = sbn.notification
        val e = n.extras
        fun str(k: String) = e.getCharSequence(k)?.toString().orEmpty()

        val title = str(Notification.EXTRA_TITLE)
        val sub = str(Notification.EXTRA_SUB_TEXT)
        val conv = str(Notification.EXTRA_CONVERSATION_TITLE)
        val text = listOf(str(Notification.EXTRA_BIG_TEXT), str(Notification.EXTRA_TEXT))
            .firstOrNull { it.isNotBlank() }.orEmpty()

        // 방 이름이 들어 있을 수 있는 모든 칸 (메시지 본문은 제외)
        val fields = listOf(
            conv, sub, title,
            str(Notification.EXTRA_TITLE_BIG),
            str(Notification.EXTRA_SUMMARY_TEXT),
            str(Notification.EXTRA_INFO_TEXT)
        ).map { Store.norm(it) }.filter { it.isNotEmpty() }

        val muted = Store.muted(this, app).any { m ->
            val nm = Store.norm(m)
            nm.isNotEmpty() && fields.any { it.contains(nm) }
        }

        // 묶음(요약) 알림은 방이 숨김 대상이면 같이 지우고 끝
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            if (muted) cancelNotification(sbn.key)
            return
        }

        val room = if (app == Store.DISCORD) {
            discordName(title, sub, conv)
        } else {
            listOf(conv, sub, title).firstOrNull { it.isNotBlank() }.orEmpty()
        }
        if (room.isBlank()) return
        Store.addKnown(this, app, room)

        val now = System.currentTimeMillis()
        if (!muted) {
            Store.addRecv(this, Recv(now, app, room, "통과"))
            return
        }

        if (Store.isMention(this, text)) {
            val del = Store.deleteMention(this)
            Store.addLog(this, Entry(now, app, room, text, del))
            Store.addRecv(this, Recv(now, app, room, if (del) "멘션 삭제" else "멘션 표시"))
            if (del) cancelNotification(sbn.key)
        } else {
            cancelNotification(sbn.key)
            Store.bumpBlocked(this)
            Store.addRecv(this, Recv(now, app, room, "숨김"))
        }
    }

    private fun discordName(title: String, sub: String, conv: String): String {
        if (sub.isNotBlank()) return sub
        if (conv.isNotBlank()) return conv
        val m = Regex("\\(([^)]*)\\)\\s*$").find(title)
        if (m != null) return m.groupValues[1].split(",").last().trim()
        return title
    }
}
