package com.alarmmanager.app

import android.app.Notification
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {

    // 메시지 본문이 들어 있는 칸은 방 이름 검사에서 제외
    private val skipKeys = setOf(
        Notification.EXTRA_TEXT,
        Notification.EXTRA_BIG_TEXT,
        Notification.EXTRA_TEXT_LINES,
        Notification.EXTRA_MESSAGES,
        Notification.EXTRA_HISTORIC_MESSAGES,
        "android.template"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Exception) {
        }
    }

    private fun collect(n: Notification): List<String> {
        val out = ArrayList<String>()
        fun scan(b: Bundle?) {
            if (b == null) return
            for (k in b.keySet()) {
                if (k in skipKeys) continue
                val v = try {
                    @Suppress("DEPRECATION")
                    b.get(k)
                } catch (_: Exception) {
                    null
                }
                if (v is CharSequence && v.isNotBlank()) out.add(v.toString())
            }
        }
        scan(n.extras)
        scan(n.publicVersion?.extras)
        return out.distinct()
    }

    // 안드로이드의 "대화" 정보(바로가기 이름, 대화 채널)에서 방 이름과 방 ID를 가져온다
    private fun conversationInfo(sbn: StatusBarNotification): Pair<List<String>, String?> {
        val names = ArrayList<String>()
        var convId: String? = null
        try {
            val r = Ranking()
            if (currentRanking.getRanking(sbn.key, r) && Build.VERSION.SDK_INT >= 30) {
                val ch = r.channel
                convId = ch?.conversationId
                if (convId != null) ch?.name?.toString()?.let { names.add(it) }
                val si = r.conversationShortcutInfo
                if (si != null) {
                    si.longLabel?.toString()?.let { names.add(it) }
                    si.shortLabel?.toString()?.let { names.add(it) }
                }
            }
        } catch (_: Exception) {
        }
        return Pair(names.filter { it.isNotBlank() }.distinct(), convId)
    }

    private fun handle(sbn: StatusBarNotification) {
        val app = when (sbn.packageName) {
            "com.kakao.talk" -> Store.KAKAO
            "com.discord" -> Store.DISCORD
            else -> return
        }
        if (app !in Store.apps(this)) return

        val n = sbn.notification
        val e = n.extras
        fun str(k: String) = e.getCharSequence(k)?.toString().orEmpty()

        val title = str(Notification.EXTRA_TITLE)
        val sub = str(Notification.EXTRA_SUB_TEXT)
        val conv = str(Notification.EXTRA_CONVERSATION_TITLE)
        val text = listOf(str(Notification.EXTRA_BIG_TEXT), str(Notification.EXTRA_TEXT))
            .firstOrNull { it.isNotBlank() }.orEmpty()

        val (convNames, convId) = conversationInfo(sbn)
        val all = (convNames + collect(n)).distinct()
        val normFields = all.map { Store.norm(it) }.filter { it.isNotEmpty() }

        // 방 식별값 (이름이 알림에 없어도 방 자체를 구분하기 위함)
        val ids = ArrayList<String>()
        val sc = n.shortcutId
        if (!sc.isNullOrBlank()) ids.add("sc:$sc")
        if (!convId.isNullOrBlank()) ids.add("cv:$convId")
        ids.add("k:${sbn.tag}:${sbn.id}")
        val rid = ids.first()

        val muted = Store.muted(this, app).any { m ->
            val id = Store.ruleId(m)
            if (id != null) {
                id in ids
            } else {
                val nm = Store.norm(m)
                nm.isNotEmpty() && normFields.any { it.contains(nm) }
            }
        }

        // 묶음(요약) 알림은 숨김 대상이면 같이 지우고 끝
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            if (muted) cancelNotification(sbn.key)
            return
        }

        var room = convNames.firstOrNull()
            ?: if (app == Store.DISCORD) {
                discordName(title, sub, conv)
            } else {
                listOf(conv, sub, title).firstOrNull { it.isNotBlank() }.orEmpty()
            }
        if (room.isBlank()) room = all.firstOrNull() ?: "(이름 없음)"
        Store.addKnown(this, app, room)

        val detail = all.joinToString(" · ").take(90)
        val now = System.currentTimeMillis()

        if (!muted) {
            Store.addRecv(this, Recv(now, app, room, "통과", detail, rid))
            return
        }

        if (Store.isMention(this, text)) {
            val del = Store.deleteMention(this)
            Store.addLog(this, Entry(now, app, room, text, del))
            Store.addRecv(this, Recv(now, app, room, if (del) "멘션 삭제" else "멘션 표시", detail, rid))
            if (del) cancelNotification(sbn.key)
        } else {
            cancelNotification(sbn.key)
            Store.bumpBlocked(this)
            Store.addRecv(this, Recv(now, app, room, "숨김", detail, rid))
        }
    }

    private fun discordName(title: String, sub: String, conv: String): String {
        if (sub.isNotBlank()) return sub
        if (conv.isNotBlank()) return conv
        val m = Regex("\\(([^)]*)\\)\\s*$").find(title)
        if (m != null) return m.groupValues[1].split(",").last().trim()
        return title
    }
}
