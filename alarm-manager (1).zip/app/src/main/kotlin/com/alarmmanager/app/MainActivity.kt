package com.alarmmanager.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF000000)
private val Card = Color(0xFF121212)
private val Line = Color(0xFF242424)
private val Txt = Color(0xFFF2F2F2)
private val SubC = Color(0xFF8A8A8A)
private val Accent = Color(0xFF8E9BFF)

private val MODES = listOf(
    Triple("kakao", "카카오톡", "카카오톡 알림만 관리해요"),
    Triple("discord", "디스코드", "디스코드 알림만 관리해요"),
    Triple("both", "둘 다", "두 앱을 함께 관리해요")
)

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Card,
                    onSurface = Txt, onBackground = Txt
                )
            ) { Root(this, resumeTick) }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

@Composable
fun Root(ctx: Context, resume: Int) {
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val sp = Store.prefs(ctx)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> tick++ }
        sp.registerOnSharedPreferenceChangeListener(l)
        onDispose { sp.unregisterOnSharedPreferenceChangeListener(l) }
    }
    val t = tick
    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
        if (Store.mode(ctx).isEmpty()) Welcome(ctx) else Main(ctx, t, resume)
    }
}

@Composable
fun Welcome(ctx: Context) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("알림 매니저", color = Txt, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("관리할 앱을 먼저 골라 주세요.", color = SubC, fontSize = 15.sp)
        Spacer(Modifier.height(32.dp))
        MODES.forEach { (key, label, desc) ->
            OptionCard(label, desc, false) { Store.setMode(ctx, key) }
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("나중에 설정에서 바꿀 수 있어요.", color = SubC, fontSize = 12.sp)
    }
}

@Composable
fun Main(ctx: Context, tick: Int, resume: Int) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val titles = listOf("방 · 서버", "멘션 로그", "설정")

    Column(Modifier.fillMaxSize()) {
        Text(
            titles[tab], color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 12.dp)
        )
        if (!granted) PermissionCard(ctx)
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Rooms(ctx, tick)
                1 -> LogTab(ctx, tick)
                else -> SettingsTab(ctx, tick)
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            titles.forEachIndexed { i, name ->
                Text(
                    name,
                    color = if (i == tab) Accent else SubC,
                    fontSize = 14.sp,
                    fontWeight = if (i == tab) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f).clickable { tab = i }.padding(vertical = 14.dp)
                )
            }
        }
    }
}

@Composable
fun PermissionCard(ctx: Context) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 12.dp)
            .clip(RoundedCornerShape(16.dp)).background(Card)
            .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("알림 접근 권한이 필요해요", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("허용해야 알림을 정리할 수 있어요", color = SubC, fontSize = 12.sp)
        }
        Spacer(Modifier.size(12.dp))
        PrimaryButton("허용") {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

@Composable
fun Rooms(ctx: Context, tick: Int) {
    val apps = Store.apps(ctx)
    var sel by remember { mutableStateOf(apps.first()) }
    val cur = if (sel in apps) sel else apps.first()
    val rooms = Store.rooms(ctx, cur)
    val muted = Store.muted(ctx, cur)
    var input by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        if (apps.size > 1) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                apps.forEach { Pill(Store.label(it), it == cur) { sel = it } }
            }
            Spacer(Modifier.height(12.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(
                input, { input = it },
                if (cur == Store.KAKAO) "방 이름 직접 추가" else "서버 이름 직접 추가",
                Modifier.weight(1f)
            )
            Spacer(Modifier.size(8.dp))
            PrimaryButton("추가") {
                val n = input.trim()
                if (n.isNotEmpty()) {
                    Store.addMuted(ctx, cur, n)
                    input = ""
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (rooms.isEmpty()) {
            Text(
                "아직 비어 있어요.\n알림이 오면 자동으로 목록에 쌓이고, 직접 추가해도 돼요.",
                color = SubC, fontSize = 14.sp, lineHeight = 21.sp,
                modifier = Modifier.padding(top = 24.dp)
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(rooms, key = { it }) { name ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                            .border(1.dp, Line, RoundedCornerShape(16.dp))
                            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            name, color = Txt, fontSize = 15.sp, maxLines = 2,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = name in muted,
                            onCheckedChange = { Store.setMuted(ctx, cur, name, it) },
                            colors = switchColors()
                        )
                        Text(
                            "✕", color = SubC, fontSize = 14.sp,
                            modifier = Modifier.clip(CircleShape)
                                .clickable { Store.removeRoom(ctx, cur, name) }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LogTab(ctx: Context, tick: Int) {
    val logs = Store.log(ctx)
    val fmt = remember { SimpleDateFormat("M/d HH:mm", Locale.KOREA) }
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        if (logs.isEmpty()) {
            Text(
                "아직 기록이 없어요.\n숨긴 방에서 나를 멘션하면 여기에 남아요.",
                color = SubC, fontSize = 14.sp, lineHeight = 21.sp,
                modifier = Modifier.padding(top = 12.dp)
            )
        } else {
            Text(
                "비우기", color = Accent, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.End).clip(CircleShape)
                    .clickable { Store.clearLog(ctx) }.padding(horizontal = 8.dp, vertical = 6.dp)
            )
            Spacer(Modifier.height(4.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(logs) { e ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                            .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${Store.label(e.app)} · ${e.room}", color = Txt, fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold, maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            Text(fmt.format(Date(e.time)), color = SubC, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(e.text.ifBlank { "(내용 없음)" }, color = SubC, fontSize = 13.sp, maxLines = 3)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (e.deleted) "삭제됨" else "표시됨",
                            color = if (e.deleted) SubC else Accent, fontSize = 11.sp,
                            modifier = Modifier.clip(CircleShape)
                                .border(1.dp, if (e.deleted) Line else Accent, CircleShape)
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(ctx: Context, tick: Int) {
    val mode = Store.mode(ctx)
    var kw by remember { mutableStateOf(Store.keywords(ctx)) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
    ) {
        SectionLabel("관리할 앱")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MODES.forEach { (key, label, _) -> Pill(label, key == mode) { Store.setMode(ctx, key) } }
        }

        Spacer(Modifier.height(28.dp))
        SectionLabel("멘션")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("멘션 알림도 삭제", color = Txt, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(
                    "끄면 멘션은 지우지 않고 화면에 표시해요",
                    color = SubC, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
            Switch(
                checked = Store.deleteMention(ctx),
                onCheckedChange = { Store.setDeleteMention(ctx, it) },
                colors = switchColors()
            )
        }
        Spacer(Modifier.height(12.dp))
        Field(kw, { kw = it; Store.setKeywords(ctx, it) }, "내 닉네임 (쉼표로 구분)", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text("메시지에 @닉네임 이 있으면 멘션으로 봐요", color = SubC, fontSize = 12.sp)

        Spacer(Modifier.height(28.dp))
        SectionLabel("통계")
        Text("지금까지 숨긴 알림 ${Store.blocked(ctx)}개", color = Txt, fontSize = 15.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SectionLabel(s: String) {
    Text(s, color = SubC, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
fun OptionCard(label: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Card)
            .border(1.dp, if (selected) Accent else Line, shape)
            .clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(desc, color = SubC, fontSize = 13.sp)
        }
        if (selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Accent))
    }
}

@Composable
fun Pill(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.Black else Txt,
        fontSize = 14.sp,
        modifier = Modifier.clip(CircleShape)
            .background(if (selected) Accent else Card)
            .border(1.dp, if (selected) Accent else Line, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        singleLine = true,
        placeholder = { Text(hint, color = SubC, fontSize = 14.sp) },
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, unfocusedBorderColor = Line,
            focusedTextColor = Txt, unfocusedTextColor = Txt, cursorColor = Accent,
            focusedContainerColor = Card, unfocusedContainerColor = Card
        )
    )
}

@Composable
fun PrimaryButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
    ) { Text(label, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.Black, checkedTrackColor = Accent, checkedBorderColor = Accent,
    uncheckedThumbColor = SubC, uncheckedTrackColor = Line, uncheckedBorderColor = Line
)
