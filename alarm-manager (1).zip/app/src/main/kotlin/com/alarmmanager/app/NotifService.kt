package com.alarmmanager.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Exception) {
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val app = when (sbn.packageName) {
            "com.kakao.talk" -> Store.KAKAO
            "com.discord" -> Store.DISCORD
            else -> return
        }
        if (app !in Store.apps(this)) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val e = n.extras
        fun str(k: String) = e.getCharSequence(k)?.toString().orEmpty()

        val title = str(Notification.EXTRA_TITLE)
        val sub = str(Notification.EXTRA_SUB_TEXT)
        val conv = str(Notification.EXTRA_CONVERSATION_TITLE)
        val text = listOf(str(Notification.EXTRA_BIG_TEXT), str(Notification.EXTRA_TEXT))
            .firstOrNull { it.isNotBlank() }.orEmpty()

        val room = if (app == Store.DISCORD) {
            discordName(title, sub, conv)
        } else {
            listOf(conv, sub, title).firstOrNull { it.isNotBlank() }.orEmpty()
        }
        if (room.isBlank()) return
        Store.addKnown(this, app, room)

        val fields = listOf(conv, sub, title).map { it.lowercase() }
        val muted = Store.muted(this, app).any { m ->
            m.isNotBlank() && fields.any { it.contains(m.lowercase()) }
        }
        if (!muted) return

        if (Store.isMention(this, text)) {
            val del = Store.deleteMention(this)
            Store.addLog(this, Entry(System.currentTimeMillis(), app, room, text, del))
            if (del) cancelNotification(sbn.key)
        } else {
            cancelNotification(sbn.key)
            Store.bumpBlocked(this)
        }
    }

    private fun discordName(title: String, sub: String, conv: String): String {
        if (sub.isNotBlank()) return sub
        if (conv.isNotBlank()) return conv
        val m = Regex("\\(([^)]*)\\)\\s*$").find(title)
        if (m != null) return m.groupValues[1].split(",").last().trim()
        return title
    }
}
